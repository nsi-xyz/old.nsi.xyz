# Cubito's Adventures v.1 NW 30/10/2020
# https://nsi.xyz/Cubito's Adventures, un jeu en python pour la NumWorks
# par Clement Raphaël et Palix Gabin

from kandinsky import *
from ion import *
from random import *
from time import *

try:
  get_keys()
  os = (192,53,53) #Se met à la couleur de l'OS alternatif Omega
except:
  os = (255,183,52) #Se met à la couleur de l'OS de base Epsilon
  
ja=(255,255,0)
ble=(0,255,255)
bl=(255,255,255)
no=(0,0,0)

def text_center(text,x=160,y=110,col1=(255,255,255),col2=(255,255,255)): #Centre un texte
    draw_string(text, x-len(text)*10 // 2, y, col1, col2)

def menu():
    global niveau
    fill_rect(0,0,320,222,no)
    fill_rect(0,204,320,18,os)
    text_center("nsi.xyz/cubito par Gab & Raph",160,204,bl,os)
    text_center("Bienvenue dans :",160,7,ja,no)
    for i in range(5,320,10):
        set_pixel(i,30,ja)
        sleep(0.05)
    text_center("Cubito's Adventures!",160,38,ja,(3,34,76))
    text_center("Pour bouger, utilise les fleches",160,61,ja,no)
    text_center("Mais, attention aux trous!",160,81,ja,no)
    text_center("Pour gagner, essaie d'avoir le",160,121,ja,no)
    text_center("plus de points!",160,141,ja,no)
    sleep(4)
    text_center("A toi de jouer!",160,166,ja,no)
    text_center('Appuie sur "OK" ou "clear"',160,186,ja,no)
    while not keydown(5):
        if keydown(4) or keydown(17):
            jeu()
        elif keydown(36):
            while not keydown(5):
                if keydown(43):
                    fill_rect(0,0,320,222,no)
                    niveau=42
                    jeu()

def initiation(): #Génère les pièces
    fill_rect(0,0,320,222,no)
    for j in range(5,222,10):
        for i in range(5,320,10):
            set_pixel(i,j,bl)
    initialisation()
            
position = [0,0]#x,y 
mvt = [0,0]#x,y 
global score
score=0
niveau=1

def initialisation(etat=0):
    global score, niveau, scale
    if etat == 0:
        fill_rect(0,204,320,18,os)
        draw_string("Score :",0,204,bl,os)
        draw_string("Niveau :",160,204,bl,os)
    else:
        draw_string(str(score),80,204,bl,os)
        draw_string(str(niveau),250,204,bl,os)

def personnage(aff=0):
    if aff==0:
        fill_rect(position[0], position[1], 10,10,no)
    else:
        fill_rect(position[0], position[1], 10,10,ja)

def collision():
    '''on vérifie les collisions, si collisions, on retourne false, sinon true on teste mvt[0] et mvt[1]''' 
    return True

def points():
    global score, position, mvt, longueur_scale
    if get_pixel(position[0]+4,position[1]-39)==(248,252,248):
        personnage(0)
        position[1]-=longueur_scale+10
        position[0]=position[0]
        mvt[1]=position[1]
        personnage(1)
    elif get_pixel(mvt[0]+5,mvt[1]+5)!=(248,252,248):
        score-=1
    else:
        score+=1

def vide():
    global position, mvt, score, niveau, chute_42
    while get_pixel(position[0]+5,position[1]+15)!=(248,252,248) and position[1]!=190:
        personnage(0)
        position[0]=position[0]
        position[1]+=10
        mvt[1]=position[1]
        score-=1
        personnage(1)
        sleep(1)
        if niveau==42:
            chute_42=True

def fin_niv():
    global niveau, position, mvt, score, abscisse_arrivee, ordonnee_arrivee
    niveau_suivant=False
    if niveau==1 and position[0]==310 and position[1]==190:
        text_center("Tu as reussi le niveau 1!",160,42,ja,no)
        text_center("Avec un score de "+str(score),160,62,ja,no)
        niveau_suivant=True

    elif niveau==2 and position[0]==150 and position[1]==70:
        text_center("Tu as reussi le niveau 2!",160,42,ja,no)
        text_center("Avec un score de "+str(score),160,62,ja,no)
        niveau_suivant=True

    elif niveau==3 and position[0]==50 and position[1]==100:
        text_center("Tu as reussi le niveau 3!",160,42,ja,no)
        text_center("Avec un score de "+str(score),160,62,ja,no)
        niveau_suivant=True

    elif niveau==4 and position[0]==240 and position[1]==130:
        text_center("Tu as reussi le niveau 4!",160,42,ja,no)
        text_center("Avec un score de "+str(score),160,62,ja,no)
        niveau_suivant=True

    elif niveau==5 and position[0]==130 and position[1]==190:
        text_center("Tu as reussi le niveau 5!",160,42,ja,no)
        text_center("Avec un score de "+str(score),160,62,ja,no)
        niveau_suivant=True

    elif niveau==42 and position[0]==abscisse_arrivee and position[1]==ordonnee_arrivee:
        text_center("Tu as reussi le niveau 42!",160,42,ja,no)
        text_center("Avec un score SUPREME de "+str(score),160,62,ja,no)
        niveau_suivant=True
        
    if niveau_suivant:
        sleep(4.2)
        if niveau==42:
            fin()
        else:
            niveau+=1
            position = [0, 0] 
            mvt = [0, 0]
            score=0
            jeu()

def scale():
    global abscisse_scale, longueur_scale, ordonnee_scale, ordonnee_scale42
    longueur_scale=40
    if niveau==1:
        ordonnee_scale=60
        fill_rect(abscisse_scale,60,10,longueur_scale,bl)
    elif niveau==2:
        ordonnee_scale=80
        fill_rect(abscisse_scale,80,10,longueur_scale,bl)
    elif niveau==3:
        ordonnee_scale=50
        fill_rect(abscisse_scale,50,10,longueur_scale,bl)
    elif niveau==4:
        ordonnee_scale=140
        fill_rect(abscisse_scale,140,10,longueur_scale,bl)
    elif niveau==5:
        ordonnee_scale=130
        fill_rect(abscisse_scale,130,10,longueur_scale,bl)
    elif niveau==42:
        ordonnee_scale=ordonnee_scale42
        fill_rect(abscisse_scale,ordonnee_scale42,10,longueur_scale,bl)
        
def move():  
    global postion, mvt 
    bordure = [0,0,190,310]
    while not keydown(5):
        vide()
        scale()   
        is_key_pressed = False
        if keydown(0): #gauche
            mvt[0] = max(position[0]-10, bordure[0])
            is_key_pressed = True

        elif keydown(1): #haut
            mvt[1] = max(position[1]-10, bordure[1])
            is_key_pressed = True

        elif keydown(2): #bas
            mvt[1] = min(position[1]+10, bordure[2])
            is_key_pressed = True

        elif keydown(3): #droite
            mvt[0] = min(position[0]+10, bordure[3])
            is_key_pressed = True

        if is_key_pressed and collision():
            points()
            sleep(0.25)
            fin_niv()
            initialisation(1)
            personnage(0)
            position[0] = mvt[0]
            position[1] = mvt[1]
            personnage(1)

def partie():
    global niveau, position, score, abscisse_scale, ordonnee_scale42, abscisse_arrivee, ordonnee_arrivee
    initiation()
    v=[]
    for i in range(0,320,10):
        v.append(i)#pas sur la même ligne de l'arrivée
    abscisse_scale=choice(v)
    ordonnee_scale42=choice(v[0:19])
    if niveau==1:
        fill_rect(310,190,10,10,ble)
    elif niveau==2:
        fill_rect(150,70,10,10,ble)
    elif niveau==3:
        fill_rect(50,100,10,10,ble)
    elif niveau==4:
        fill_rect(240,130,10,10,ble)
    elif niveau==5:
        fill_rect(130,190,10,10,ble)
    elif niveau==42:
        x, y = [], []
        for i in range(0,310,10):
            x.append(i)
        for j in range(20,190,10):
            y.append(j)
        abscisse_arrivee=choice(x)
        ordonnee_arrivee=choice(y)
        fill_rect(abscisse_arrivee,ordonnee_arrivee,10,10,ble)
    move()

def fin():
    fill_rect(0,0,320,222,no)
    text_center("Tu as fini le dernier niveau!!",160,42,bl,no)
    fill_rect(0,204,320,18,os)
    draw_string("Score :",0,204,bl,os)
    draw_string("Niveau :",160,204,bl,os)
    sleep(4.2)

def jeu():
    global niveau
    while niveau!=6:
        fill_rect(0,0,320,222,no)
        sleep(2)
        partie()
    fill_rect(0,0,320,222,no)
    text_center("Tu as gagné!!!",160,42,ja,no)
    fill_rect(0,204,320,18,os)
    draw_string("Score :",0,204,bl,os)
    draw_string("Niveau :",160,204,bl,os)
    sleep(4.2)
menu()