import random
#Questions Globales  # la répétition correspond a la bonne réponse
 
print(" Taper la bonne réponse A,B ou C ( ne pas oublier les majuscules , c'est une série de 14 questions . Si vous répondez autre chose que A B C le programme plantera il faudra le relancer . " )
 
 
Question = [["Quel est le participe passé de mourir en espagnol ?","A :Merto","B :Muerto","C :Morto","B :Muerto"],
            ["Quel est le participe passé de dire en espagnol  ? ","A :Dicho","B :Diche","C :Diecho","A :Dicho"],
            ["Quel est le participe passé de faire en espagnol ?","A :Hecho","B :Hechio","C :Hacer","A :Hecho"],
            ["Quel est le participe passé de casser en espagnol ?","A :Rota","B :Rato","C :Roto","C :Roto"],
            ["Quel est le participe passé de voir en espagnol ?","A :Visto","B :Viesto","C :Viste","A :Visto"] ,
            ["Quel est le participe passé de mettre en espagnol ? ","A :Pesto","B :Puesto","C :Pusto","B :Puesto"],
            ["Quel est le participe passé de revenir en espagnol ?","A :Vulte","B :Vuelte","C :Vuelto","C :Vuelto"],
            ["Quel est le participe passé de ouvrir en espagnol ?","A :Abrir","B :Abierto","C :Aberto","B :Abierto"],
            ["Quel est le participe passé de écrire en espagnol ?","A :Escrite","B :Escriento","C :Escrito","C :Escrito"],
            ["Quel est le participe passé de découvrir en espagnol ?","A :Describierto","B :Descubierte","C :Descubierto","C :Descubierto "],
            ["Quel est le participe passé de couvrir en espagnol ?","A :Cubierto","B :Cubrito","C :Cubriento","A :Cubierto"],
            ["Quel est le participe passé de imposer en espagnol ?","A :Imposto","B :Impuesto","C :Impueste","B :Impuesto"],
            ["Quel est le participe passé de décrire en espagnol ?","A :Descriente","B :Descrito","C :Descriento","B :Descrito"],
            ["Quel est le participe passé de satisfaire en espagnol ? ","A :Satisfeche","B :Satisfecho","C :Satisficho","B :Satisfecho"]]
              
 
qtal = Question #On enleve des éléments de la liste pour ne pas répéter la question.
 
score = 0 
x = 0
while x < 14 :
    for i in range(0,1):
     lQst = random.choice(qtal)  #On prend une question
     qtal.remove(lQst)  #Qu'on enleve de notre liste de questions
     
     print(lQst[0])  #On l'affiche
  
      
     print(lQst[1]) #Les 3 réponses
     print(lQst[2])
     print(lQst[3])
   
     lRep = ""
     lRep != ["A","B","C"]
 
     lRep = str(input("Votre réponse: ")) #On redemande
   
     if lRep == "A": #On récupère le choix
      lChx = lQst[1]
       
     if lRep == "B":
      lChx = lQst[2]
     if lRep == "C":
      lChx = lQst[3]
  
     if lChx == lQst[4]: #rpvrai
      print("-- VRAI --\n")
      print("Nouvelle question : " )
      x += 1
      score = score+1
       
     else: #Sinon
      print("-- FAUX --\n")
      print(" La bonne réponse était : "), print(lQst[4])
 
      print("Nouvelle question : " )
      x += 1
      
 
x = 14
print(" Fin du QCM ! " )
print(" Votre score est de : ", score, "sur 14")  